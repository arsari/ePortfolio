package com.arsari.inventoryapp;

/*
 * Arturo Santiago-Rivera
 * CS-360-X6386 Mobile Architect & Programming 21EW6
 * Southern New Hampshire University
 * August 2021
 */

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;


public class LoginActivity extends AppCompatActivity {

    Button LoginButton, RegisterButton ;
    EditText Email, Password ;
    String NameHolder, PhoneNumberHolder, EmailHolder, PasswordHolder;
    Boolean EditTextEmptyHolder;
    SQLiteDatabase sqLiteDatabaseObj;
    UserSQLiteHelper sqLiteHelper;
    Cursor cursor;
    String TempPassword = "NOT_FOUND" ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        LoginButton = findViewById(R.id.signupButton);
        RegisterButton = findViewById(R.id.registerButton);
        Email = findViewById(R.id.editTextEmailAddress);
        Password = findViewById(R.id.editTextPassword);
        sqLiteHelper = new UserSQLiteHelper(this);

        // Adding click listener to sign in button
        LoginButton.setOnClickListener(view -> {
            // Checking editText fields are not empty
            CheckEditTextStatus();
            // Call Login function
            LoginFunction();
        });

        // Adding click listener to register button.
        RegisterButton.setOnClickListener(view -> {
            // Opening new RegisterActivity using intent on button click.
            Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
            startActivity(intent);
        });
    }

    // Login function
    public void LoginFunction() {
        if(EditTextEmptyHolder) {
            // Opening SQLite database write permission
            sqLiteDatabaseObj = sqLiteHelper.getWritableDatabase();

            // Adding search email query to cursor
            cursor = sqLiteDatabaseObj.query(UserSQLiteHelper.TABLE_NAME, null, " " + UserSQLiteHelper.Table_Column_3_Email + "=?", new String[]{EmailHolder}, null, null, null);

            while (cursor.moveToNext()) {
                if (cursor.isFirst()) {
                    cursor.moveToFirst();

                    // Storing Password and Name associated with entered email
                    TempPassword = cursor.getString(cursor.getColumnIndex(UserSQLiteHelper.Table_Column_4_Password));
                    NameHolder = cursor.getString(cursor.getColumnIndex(UserSQLiteHelper.Table_Column_1_Name));
                    PhoneNumberHolder = cursor.getString(cursor.getColumnIndex(UserSQLiteHelper.Table_Column_2_PhoneNumber));

                    // Closing cursor.
                    cursor.close();
                }
            }
            // Calling method to check final result ..
            CheckFinalResult();
        }
        else {
            //If any of login EditText empty then this block will be executed.
            Toast.makeText(LoginActivity.this,"Enter Email and Password",Toast.LENGTH_LONG).show();
        }
    }

    // Checking editText fields are not empty.
    public void CheckEditTextStatus(){
        // Getting value from editText and storing into string variables.
        EmailHolder = Email.getText().toString();
        PasswordHolder = Password.getText().toString();

        // Checking EditText is empty or dialog_no_button using TextUtils.
        if( TextUtils.isEmpty(EmailHolder) || TextUtils.isEmpty(PasswordHolder)){
            EditTextEmptyHolder = false ;
        }
        else {
            EditTextEmptyHolder = true ;
        }
    }

    // Checking entered password from SQLite database email associated password
    public void CheckFinalResult(){
        if(TempPassword.equalsIgnoreCase(PasswordHolder))
        {
            Toast.makeText(LoginActivity.this,"Login Successful",Toast.LENGTH_LONG).show();

            // Sending Name to ItemsActivity using intent
            Bundle bundle = new Bundle();
            bundle.putString("user_name", NameHolder);
            bundle.putString("user_email", EmailHolder);
            bundle.putString("user_phone_number", PhoneNumberHolder);
            // Going to ItemsActivity after login success message
            Intent intent = new Intent(LoginActivity.this, ItemsActivity.class);
            intent.putExtras(bundle);
            startActivity(intent);
            // Empty editText  after login successful and close database
            EmptyEditTextAfterDataInsert();
            sqLiteHelper.close();

        }
        else {
            // Display error message if credentials are not correct
            Toast.makeText(LoginActivity.this,"Incorrect Email or Password\nor User Not Registered",Toast.LENGTH_LONG).show();
        }
        TempPassword = "NOT_FOUND" ;
    }

    // Empty edittext after login successful
    public void EmptyEditTextAfterDataInsert() {
        Email.getText().clear();
        Password.getText().clear();
    }
}