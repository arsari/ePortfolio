package com.arsari.inventoryapp;

/*
 * Arturo Santiago-Rivera
 * CS-360-X6386 Mobile Architect & Programming 21EW6
 * Southern New Hampshire University
 * August 2021
 */

import android.content.Context;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteDatabase;


public class UserSQLiteHelper extends SQLiteOpenHelper {

    static String DATABASE_NAME = "UsersDataBase.DB";

    public static final String TABLE_NAME = "UserTable";
    public static final String Table_Column_ID = "_id";
    public static final String Table_Column_1_Name = "name";
    public static final String Table_Column_2_PhoneNumber = "phonenumber";
    public static final String Table_Column_3_Email = "email";
    public static final String Table_Column_4_Password = "password";

    public UserSQLiteHelper(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase database) {
        String CREATE_TABLE="CREATE TABLE IF NOT EXISTS "+TABLE_NAME+" ("+Table_Column_ID+" INTEGER PRIMARY KEY, "+Table_Column_1_Name+" VARCHAR, "+Table_Column_2_PhoneNumber+" VARCHAR, "+Table_Column_3_Email+" VARCHAR, "+Table_Column_4_Password+" VARCHAR)";
        database.execSQL(CREATE_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS "+TABLE_NAME);
        onCreate(db);
    }
}