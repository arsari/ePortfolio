package com.arsari.inventoryapp;

/*
 * Arturo Santiago-Rivera
 * CS-360-X6386 Mobile Architect & Programming 21EW6
 * Southern New Hampshire University
 * August 2021
 */

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class RegisterActivity extends AppCompatActivity {

    EditText Name, Phone, Email, Password;
    Button RegisterButton;
    String NameHolder, PhoneNumberHolder, EmailHolder, PasswordHolder;
    Boolean EditTextEmptyHolder;
    SQLiteDatabase sqLiteDatabaseObj;
    String SQLiteDataBaseQueryHolder ;
    UserSQLiteHelper sqLiteHelper;
    Cursor cursor;
    String F_Result = "Not_Found";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        Name = findViewById(R.id.editTextPersonName);
        Phone = findViewById(R.id.editTextPhoneNumber);
        Email = findViewById(R.id.editTextEmailAddress);
        Password = findViewById(R.id.editTextPassword);
        RegisterButton = findViewById(R.id.signupButton);
        sqLiteHelper = new UserSQLiteHelper(this);

        // Adding click listener to register button
        RegisterButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Creating SQLite database if doesn't exists
                SQLiteDataBaseBuild();
                // Creating SQLite table if doesn't exists
                SQLiteTableBuild();
                // Checking editText fields are not empty
                CheckEditTextNotEmpty();
                // Check if email already exists in database
                CheckEmailAlreadyExists();
                // Empty editText fields after done inserting in database
                EmptyEditTextAfterDataInsert();
            }
        });
    }

    // SQLite database build method
    public void SQLiteDataBaseBuild(){
        sqLiteDatabaseObj = openOrCreateDatabase(UserSQLiteHelper.DATABASE_NAME, Context.MODE_PRIVATE, null);
    }

    // SQLite table build method
    public void SQLiteTableBuild() {
        sqLiteDatabaseObj.execSQL("CREATE TABLE IF NOT EXISTS " + UserSQLiteHelper.TABLE_NAME + "(" + UserSQLiteHelper.Table_Column_ID + " PRIMARY KEY AUTOINCREMENT NOT NULL, " + UserSQLiteHelper.Table_Column_1_Name + " VARCHAR, " + UserSQLiteHelper.Table_Column_2_PhoneNumber + " VARCHAR, " + UserSQLiteHelper.Table_Column_3_Email + " VARCHAR, " + UserSQLiteHelper.Table_Column_4_Password + " VARCHAR);");
    }

    // Register new user into database
    public void InsertDataIntoDatabase(){
        // If editText is not empty then this block will executed.
        if(EditTextEmptyHolder)
        {
            // SQLite query to insert data into table.
            SQLiteDataBaseQueryHolder = "INSERT INTO "+ UserSQLiteHelper.TABLE_NAME+" (name,phonenumber,email,password) VALUES('"+NameHolder+"', '"+PhoneNumberHolder+"', '"+EmailHolder+"', '"+PasswordHolder+"');";
            // Executing query.
            sqLiteDatabaseObj.execSQL(SQLiteDataBaseQueryHolder);
            // Closing SQLite database object.
            sqLiteDatabaseObj.close();
            // Printing toast message after done inserting.
            Toast.makeText(RegisterActivity.this,"User Registered Successfully", Toast.LENGTH_LONG).show();
            // Going back to LoginActivity after register success message
            startActivity(new Intent(RegisterActivity.this, LoginActivity.class));
            finish();
        }
        // This block will execute if any of the editText fields is empty
        else {
            // Printing toast message if any of editText is empty
            Toast.makeText(RegisterActivity.this,"Please Fill All The Required Fields.", Toast.LENGTH_LONG).show();
        }
    }

    // Check editText fields are not empty
    public void CheckEditTextNotEmpty(){
        // Getting value from All EditText and storing into String Variables.
        NameHolder = Name.getText().toString().trim();
        PhoneNumberHolder = Phone.getText().toString().trim();
        EmailHolder = Email.getText().toString().trim();
        PasswordHolder = Password.getText().toString().trim();

        if(TextUtils.isEmpty(NameHolder) || TextUtils.isEmpty(PhoneNumberHolder) || TextUtils.isEmpty(EmailHolder) || TextUtils.isEmpty(PasswordHolder)){
            EditTextEmptyHolder = false ;
        }
        else {
            EditTextEmptyHolder = true ;
        }
    }

    // Check if user email already exists in database
    public void CheckEmailAlreadyExists(){
        // Opening SQLite database write permission
        sqLiteDatabaseObj = sqLiteHelper.getWritableDatabase();

        // Adding search email query to cursor
        cursor = sqLiteDatabaseObj.query(UserSQLiteHelper.TABLE_NAME, null, " " + UserSQLiteHelper.Table_Column_3_Email + "=?", new String[]{EmailHolder}, null, null, null);

        while (cursor.moveToNext()) {
            if (cursor.isFirst()) {
                cursor.moveToFirst();
                // If email exists then set result variable value as Email Found
                F_Result = "Email Found";
                // Closing cursor.
                cursor.close();
            }
        }
        // Calling method to check final result and insert data into SQLite database
        CheckFinalCredentials();
    }

    // Check login credentials are correct
    public void CheckFinalCredentials(){
        // Checking whether email is already in database
        if(F_Result.equalsIgnoreCase("Email Found"))
        {
            // If email is exists then toast msg will display
            Toast.makeText(RegisterActivity.this,"Email Already Exists",Toast.LENGTH_LONG).show();
        }
        else {
            // If email already doesn't exists then user registration details will entered to SQLite database
            InsertDataIntoDatabase();
        }
        F_Result = "Not_Found" ;
    }

    // Empty edittext after done inserting in database
    public void EmptyEditTextAfterDataInsert(){
        Name.getText().clear();
        Phone.getText().clear();
        Email.getText().clear();
        Password.getText().clear();
    }

}