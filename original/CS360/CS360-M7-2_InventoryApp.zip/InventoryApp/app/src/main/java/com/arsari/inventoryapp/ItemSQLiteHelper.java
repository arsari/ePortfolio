package com.arsari.inventoryapp;

/*
 * Arturo Santiago-Rivera
 * CS-360-X6386 Mobile Architect & Programming 21EW6
 * Southern New Hampshire University
 * August 2021
 */

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;


public class ItemSQLiteHelper extends SQLiteOpenHelper {

    static String DATABASE_NAME = "ItemsDataBase.DB";

    public static final String TABLE_NAME = "ItemTable";
    public static final String Table_Column_ID = "_id";
    public static final String Table_Column_1_UserEmail = "useremail";
    public static final String Table_Column_2_Description = "description";
    public static final String Table_Column_3_Quantity = "quantity";

    public ItemSQLiteHelper(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase database) {
        String CREATE_TABLE="CREATE TABLE IF NOT EXISTS "+TABLE_NAME+" ("+Table_Column_ID+" INTEGER PRIMARY KEY, "+Table_Column_1_UserEmail+" VARCHAR, "+Table_Column_2_Description+" VARCHAR, "+Table_Column_3_Quantity+" VARCHAR)";
        database.execSQL(CREATE_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }
}
