package com.arsari.inventoryapp;

/*
  Arturo Santiago-Rivera
  CS-360-X6386 Mobile Architect & Programming 21EW6
  Southern New Hampshire University
  August 2021
 */

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.telephony.SmsManager;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.util.ArrayList;

/*
 NOTEs FOR COMPLETION OF THIS PROJECT:
 1. This ItemsActivity is not complete. Need to work the display of the items in the ItemsActivity.
 2. All te futures of the app will work only with the item with ID 1 in the database.
 3. The AddItem button will add a new item in the database and will insert the new item in the grid layout row.
 4. The Delete button will delete the item with ID 2 in the database.
 5. The Increase and Decrease button will change the quantity for the last item added and will overwrite the item with ID 1 in the database.
 6. Refactor of the datacase CRUD by joining the ItemDBManager and the ItemSQLiteHelper.
 */


public class ItemsActivity extends AppCompatActivity {

    String NameHolder, EmailHolder, PhoneNumHolder;
    TextView UserName, ItemQtyValue, ItemDescValue;
    ImageButton AddItemButton, SmsButton, IncreaseQty, DecreaseQty, RowDelButton;
    AlertDialog AlertDialog = null;
    RadioButton RowRadioButton = null;
    Boolean RadioButtonState = false;
    String phoneNo;
    String smsMsg;
    ItemDBManager dbManager = new ItemDBManager(ItemsActivity.this);
    // temporary view to list database content
    ListView ItemsListView;

    public static final String UserEmail = "";
    private static boolean smsAuthorized = false;
    private static final int USER_PERMISSIONS_REQUEST_SEND_SMS = 0;

    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN_MR1)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_items);

        // Initiate buttons, textViews, and editText variables
        UserName = findViewById(R.id.textViewUserName);
        ItemDescValue = findViewById(R.id.itemDescription1);
        ItemQtyValue = findViewById(R.id.itemQuantity1);
        AddItemButton = findViewById(R.id.addItemButton);
        SmsButton = findViewById(R.id.smsNotification);
        IncreaseQty = findViewById(R.id.increaseItemQty);
        DecreaseQty = findViewById(R.id.decreaseItemQty);
        RowDelButton = findViewById(R.id.rowDelButton1);
        // temporary view to list database content
        ItemsListView = findViewById(R.id.bodyListView);

        // Receiving user name and user email send by LoginActivity
        Bundle bundle = getIntent().getExtras();
        if (bundle != null) {
            NameHolder = bundle.getString("user_name");
            EmailHolder = bundle.getString("user_email");
            PhoneNumHolder = bundle.getString("user_phone_number");
            // Setting user name in textViewUserName
            UserName.setText(getString(R.string.salutation, NameHolder.toUpperCase()));
        }

        // Get items from database and list them in the ItemsActivity
        ReadFromDatabase();

        // Adding click listener to addItemButton
        AddItemButton.setOnClickListener(view -> {
            // Opening new AddItemActivity using intent on button click.
            Intent add = new Intent(ItemsActivity.this, AddItemActivity.class);
            add.putExtra(UserEmail, EmailHolder);
            startActivityForResult(add, 1); // can't find a substitute method
        });

        // Adding click listener to smsNotification
        SmsButton.setOnClickListener(view -> {
            // Request sms permission for the device
            if (ContextCompat.checkSelfPermission(this,
                    Manifest.permission.SEND_SMS)
                    != PackageManager.PERMISSION_GRANTED) {

                if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                        Manifest.permission.SEND_SMS)) {
                    Toast.makeText(ItemsActivity.this,"Device SMS Permission is Needed", Toast.LENGTH_LONG).show();
                } else {
                    ActivityCompat.requestPermissions(this,
                            new String[]{Manifest.permission.SEND_SMS},
                            USER_PERMISSIONS_REQUEST_SEND_SMS);
                }
            } else {
                Toast.makeText(ItemsActivity.this,"Device SMS Permission is Allowed", Toast.LENGTH_LONG).show();
            }
            // Open new Alert Dialog
            AlertDialog = PermissionNotificationSMS.doubleButton(ItemsActivity.this);
            AlertDialog.show();
        });

        // Adding click listener to increaseQtyButton
        IncreaseQty.setOnClickListener(view -> {
            if (RadioButtonState) {
                int input = 0, total;

                String value = ItemQtyValue.getText().toString().trim();

                if (!value.isEmpty()) {
                    input = Integer.parseInt(value);
                }

                total = input + 1;

                if (total == 1) {
                    NormalQtyCellColor();
                }

                ItemQtyValue.setText(String.valueOf(total));
                UpdateItemQtyInDatabase();
                CheckItemQtyValueCell();
            } else {
                Toast.makeText(ItemsActivity.this,"Select an Item", Toast.LENGTH_LONG).show();
            }
        });

        // Adding click listener to increaseQtyButton
        DecreaseQty.setOnClickListener(view -> {
            if (RadioButtonState) {
                int input, total;

                String value = ItemQtyValue.getText().toString().trim();

                if (value.isEmpty() || value.equals("0")) {
                    Toast.makeText(ItemsActivity.this,"Item Quantity is Zero", Toast.LENGTH_LONG).show();
                } else {
                    input = Integer.parseInt(value);

                    total = input - 1;

                    if (total == 0) {
                        ZeroValueQtyCellColor();
                    }

                    ItemQtyValue.setText(String.valueOf(total));
                    UpdateItemQtyInDatabase();
                    CheckItemQtyValueCell();
                }
            } else {
                Toast.makeText(ItemsActivity.this,"Select an Item", Toast.LENGTH_LONG).show();
            }
        });

        // Adding click listener to rowDelButton
        RowDelButton.setOnClickListener(view -> {
            if (RadioButtonState) {
                dbManager.delete(1);
                ItemDescValue.setText(null);
                ItemQtyValue.setText(null);
                NormalQtyCellColor();
                RowRadioButton.setChecked(false);
                ReadFromDatabase();
                Toast.makeText(ItemsActivity.this,"Item Deleted", Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(ItemsActivity.this,"Select an Item", Toast.LENGTH_LONG).show();
            }
        });
    }

    // Check selected Radio Button and status
    public void CheckRadioButtonClicked(View view) {
        boolean checked = ((RadioButton) view).isChecked();
        int selectedId = view.getId();

        if (RowRadioButton == null) {
            RowRadioButton = view.findViewById(selectedId);
        } else if (RowRadioButton.getId() != selectedId) {
            RowRadioButton.setChecked(false);
            RowRadioButton = null;
            RowRadioButton = view.findViewById(selectedId);
        } else {
            RowRadioButton.setChecked(false);
            RadioButtonState = RowRadioButton.isChecked();
            RowRadioButton = null;
        }

        if (RowRadioButton != null) {
            if (ItemDescValue.getText().toString().trim().isEmpty()) {
                RowRadioButton.setChecked(false);
                Toast.makeText(ItemsActivity.this, "No Item to Select", Toast.LENGTH_LONG).show();
            } else {
                RowRadioButton.setChecked(checked);
                RadioButtonState = RowRadioButton.isChecked();
            }
        }
    }

    // Setting sing out menu item in AppBar
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.appbar_items_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.signoutMenuItem) {
            // End ItemsActivity on menu item click.
            dbManager.close();
            super.finish();
            Toast.makeText(ItemsActivity.this,"Log Out Successful", Toast.LENGTH_LONG).show();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    // Get items from database
    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN_MR1)
    public void ReadFromDatabase() {
        dbManager.open();
        Cursor cursor = dbManager.fetch();
        ArrayList<String> theList = new ArrayList<>();
        Cursor data = dbManager.getAllData();

        if (cursor.getCount() > 0) {
            cursor.moveToFirst();
            ItemDescValue.setText(cursor.getString(2));
            ItemQtyValue.setText(cursor.getString(3));
            while(data.moveToNext()) {
                theList.add(data.getString(2));
                ListAdapter listAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, theList);
                ItemsListView.setAdapter(listAdapter);
            }
        } else {
            Toast.makeText(ItemsActivity.this,"Database is Empty", Toast.LENGTH_LONG).show();
        }

        CheckItemQtyValueCell();
        cursor.close();
    }

    // Received results from AddItemActivity edit text fields
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1) {
            if (resultCode == 1) {
                ItemInfo newItemInfo = (ItemInfo) data.getSerializableExtra("InfoBundle");

                String desc = newItemInfo.getItemDescription();
                String qty = newItemInfo.getItemQty();

                if (qty.equals("0")) {
                    ZeroValueQtyCellColor();
                } else {
                    NormalQtyCellColor();
                }

                ItemDescValue.setText(desc);
                ItemQtyValue.setText(qty);

                CheckItemQtyValueCell();

                // Get items and list items in database for current user email
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                    ReadFromDatabase();
                }
            } else {
                Toast.makeText(ItemsActivity.this, "Canceled", Toast.LENGTH_LONG).show();
            }
        }
    }

    // Update item quantity dynamically in database
    public void UpdateItemQtyInDatabase() {
        String email = EmailHolder;
        String desc = ItemDescValue.getText().toString().trim();
        String qty = ItemQtyValue.getText().toString().trim();

        dbManager.update(1, email, desc, qty);
    }

    // Check item qty value after import from database
    public void CheckItemQtyValueCell() {
        String value = ItemQtyValue.getText().toString().trim();

        // Check is the cell value is zero to change color and send SMS
        if (value.equals("0")) {
            ZeroValueQtyCellColor();

            // Send SMS after 2 seconds
            Handler handler = new Handler();
            handler.postDelayed(this::SendSMSMessage, 1500);
        }
    }

    // Change background color and text color of item qty cell if value is zero
    public void ZeroValueQtyCellColor() {
        ItemQtyValue.setBackgroundColor(Color.RED);
        ItemQtyValue.setTextColor(Color.WHITE);
    }

    // Change background color and text color of item qty cell to default
    public void NormalQtyCellColor() {
        ItemQtyValue.setBackgroundColor(Color.parseColor("#E6E6E6"));
        ItemQtyValue.setTextColor(Color.BLACK);
    }

    // Received and evaluate user response from AlertDialog to send SMS
    public static void AllowSendSMS() {
        smsAuthorized = true;
    }

    public static void DenySendSMS() {
        smsAuthorized = false;
    }

    public void SendSMSMessage() {
        phoneNo = PhoneNumHolder;
        smsMsg = "Please, you have items with zero value in your Inventory App.";

        // Evaluate AlertDialog permission to send SMS and ItemQtyValue value
            if (smsAuthorized && ItemQtyValue.getText().toString().equals("0")) {
                try {
                    SmsManager smsManager = SmsManager.getDefault();
                    smsManager.sendTextMessage(phoneNo, null, smsMsg, null, null);
                    Toast.makeText(getApplicationContext(), "SMS Sent",
                            Toast.LENGTH_LONG).show();
                } catch (Exception ex) {
                    Toast.makeText(getApplicationContext(), "Device Permission Denied",
                            Toast.LENGTH_LONG).show();
                    ex.printStackTrace();
                }
            } else {
                Toast.makeText(ItemsActivity.this, "App SMS Alert Disable", Toast.LENGTH_LONG).show();
            }
    }

//    // Add new row to itemsGridLayout
//    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN_MR1)
//    public void AddNewItemRow() {
//        // Get application context.
//        Context context = getApplicationContext();
//
//        // Get the GridLayout layout object.
//        final GridLayout gridLayout = findViewById(R.id.itemsGridLayout);
//
//        RadioButton radiobutton = new RadioButton(context);
//        radiobutton.setOnClickListener(this::CheckRadioButtonClicked);
//        radiobutton.setId(View.generateViewId());
//        TextView tvDesc = new TextView(context);
//        TextView tvQty = new TextView(context);
//        ImageButton image_button = new ImageButton(context);
//
//        gridLayout.addView(radiobutton);
//    }
}