package com.arsari.inventoryapp;

/*
  Arturo Santiago-Rivera
  CS-360-X6386 Mobile Architect & Programming 21EW6
  Southern New Hampshire University
  August 2021
 */

import android.content.DialogInterface;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;


public class PermissionNotificationSMS {

    public static AlertDialog doubleButton(final ItemsActivity context){
        // Use the Builder class for convenient dialog construction
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle(R.string.sms_dialog_title)
                .setIcon(R.drawable.sms_notification)
                .setCancelable(false)
                .setMessage(R.string.sms_dialog_permission_msg)
                .setPositiveButton(R.string.sms_dialog_enable_button, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int arg1) {
                        Toast.makeText(context, "SMS Alerts Enable", Toast.LENGTH_LONG).show();
                        ItemsActivity.AllowSendSMS();
                        dialog.cancel();
                    }
                })
                .setNegativeButton(R.string.sms_dialog_disable_button, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int arg1) {
                        Toast.makeText(context, "SMS Alerts Disable", Toast.LENGTH_LONG).show();
                        ItemsActivity.DenySendSMS();
                        dialog.cancel();
                    }
                });

        // Create the AlertDialog object and return it
        AlertDialog alertDialog = builder.create();
        return alertDialog;
    }
}
