package com.arsari.inventoryapp;

/*
 * Arturo Santiago-Rivera
 * CS-360-X6386 Mobile Architect & Programming 21EW6
 * Southern New Hampshire University
 * August 2021
 */

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;


// Method to do CRUD activities in ItemsDatabase.DB
public class ItemDBManager {

    private final Context context;
    private SQLiteDatabase database;
    private ItemSQLiteHelper dbHelper;

    public ItemDBManager(Context c) {
        this.context = c;
    }

    public ItemDBManager open() throws SQLException {
        this.dbHelper = new ItemSQLiteHelper(this.context);
        this.database = this.dbHelper.getWritableDatabase();
        return this;
    }

    public void close() {
        this.dbHelper.close();
    }

//    public void insert(String email, String desc, String qty) {
//        ContentValues contentValue = new ContentValues();
//        contentValue.put(ItemSQLiteHelper.Table_Column_1_UserEmail, email);
//        contentValue.put(ItemSQLiteHelper.Table_Column_2_Description, desc);
//        contentValue.put(ItemSQLiteHelper.Table_Column_3_Quantity, qty);
//        this.database.insert(ItemSQLiteHelper.TABLE_NAME, null, contentValue);
//    }

    public Cursor fetch() {
        Cursor cursor = this.database.query(ItemSQLiteHelper.TABLE_NAME, new String[]{ItemSQLiteHelper.Table_Column_ID, ItemSQLiteHelper.Table_Column_1_UserEmail, ItemSQLiteHelper.Table_Column_2_Description, ItemSQLiteHelper.Table_Column_3_Quantity}, null, null, null, null, null);
        if (cursor != null) {
            cursor.moveToFirst();
        }
        return cursor;
    }

    public int update(long _id, String email, String desc, String qty) {
        ContentValues contentValues = new ContentValues();
        contentValues.put(ItemSQLiteHelper.Table_Column_1_UserEmail, email);
        contentValues.put(ItemSQLiteHelper.Table_Column_2_Description, desc);
        contentValues.put(ItemSQLiteHelper.Table_Column_3_Quantity, qty);
        return this.database.update(ItemSQLiteHelper.TABLE_NAME, contentValues, "_id = " + _id, null);
    }

    public void delete(long _id) {
        this.database.delete(ItemSQLiteHelper.TABLE_NAME, "_id=" + _id, null);
    }

    public Cursor getAllData() {
        return this.database.rawQuery("SELECT * FROM " + ItemSQLiteHelper.TABLE_NAME, null);
    }
}